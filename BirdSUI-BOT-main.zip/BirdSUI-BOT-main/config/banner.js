function printBanner() {
  console.log("========== BirdSUI BOT ==========");
  console.log("GitHub: https://github.com/Galkurta");
  console.log("Telegram: https://t.me/galkurtarchive");
  console.log("=================================");
}
module.exports = printBanner;
